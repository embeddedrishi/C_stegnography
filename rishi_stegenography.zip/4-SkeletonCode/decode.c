/*
Name:Hrishikesh Kale
Date:
Description:
Sample I/P:
Sample O/P:
 */
#include <stdio.h>
#include <string.h>
#include "decode.h"
#include "types.h"
#include "common.h"
#include <unistd.h>

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */


/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */

Status open_dfiles(DecodeInfo *decInfo,int flag)
{
    if(flag==0)
    {

	// Stego Image file
	decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "r");
	// Do Error handling
	if (decInfo->fptr_stego_image == NULL)
	{
	    perror("fopen");
	    fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->stego_image_fname);

	    return e_failure;
	}
    }
    else
    {
	decInfo->fptr_secret= fopen(decInfo->secret_fname,"w");
	if (decInfo->fptr_secret == NULL)
	{
	    perror("fopen");
	    fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->stego_image_fname);

	    return e_failure;
	}
    }

    // No failure return e_success
    return e_success;
}
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    char *extn;
    if( strcmp(strstr(argv[2],"."),".bmp")==0)
    {
	decInfo->stego_image_fname = argv[2];

    }
    else
    {
	return e_failure;
    }
    if(argv[3]!=NULL)
    {
	decInfo->secret_fname=argv[3];
    }
    else
    {
	decInfo->secret_fname="decode_text.txt";
    }
    return e_success;


}
int flag=0;
Status do_decoding(DecodeInfo *decInfo)
{
    if(open_dfiles(decInfo,flag) == e_success)
    {
	flag=1;
	printf("INFO : Opening files succesfull\n");
	printf("\n");
	fseek(decInfo->fptr_stego_image,54,SEEK_SET);

	if(decode_magic_string(MAGIC_STRING,decInfo)==e_success)
	{
	    sleep(1);
	    printf("INFO : Magic String found\n");
	    printf("\n");
	   if( dec_secret_file_extn_size(decInfo) == e_success)
	   {
	    sleep(1);
	    printf("INFO : File Extension size decoded Sucessfully\n");
	    printf("\n");
	    if(decode_secret_file_extn(decInfo)==e_success)
	    {
		sleep(1);
		printf("INFO : File extension decode successfully\n");
		printf("\n");
		if(open_dfiles(decInfo,flag)==e_success)
		{
		    printf("INFO : Secret file open succesfully\n");
		    printf("\n");

		    if(decode_secret_file_size(decInfo)==e_success)
		    {
			sleep(1);
			printf("INFO : File data size decoded successfully\n");
			printf("\n");

			flag=0;
			if(decode_secret_file_data(decInfo)==e_success)
			{
			    sleep(1);
			    printf("INFO : Secret Data decoded succesfully\n");
			    printf("\n");

			}
			else
			    printf("ERROR : Secret data cannot be decoded\n");
		    }
		    else
			printf("ERROR : File data size cannot be decoded\n");

		}
		else
		    printf("ERROR : Secret file cannnot opened\n");
	    }
	    else
	   	printf("ERROR : Secret extention cannot be decoded\n");
	   }
	   else
	       printf("ERROR : Secret extention size decoded\n");

	}
	else
	    printf("ERROR : Magic string cannot be decoded");
    }
    else
    {
	return e_failure;
    }
}





Status decode_magic_string(char *magic_string, DecodeInfo *decInfo)
{
    int size=strlen(magic_string);
    char decode_magic_str[size];
 //  printf("%d", sizeof(decode_magic_str));
    if(decode_image_to_data(decode_magic_str,size,decInfo->fptr_stego_image,decInfo->fptr_secret) == e_success)
    {
	if(strcmp(decode_magic_str,magic_string) == 0) 
	    return e_success;
    }

}
Status decode_image_to_data(char *data, int size, FILE *fptr_stego_image, FILE *fptr_secret)
{
    char image_buffer[8];

int i;
    for( i=0 ; i < size ; i++)
    {
	data[i]=0;
	fread(image_buffer,sizeof(image_buffer),1,fptr_stego_image);
	decode_lsb_to_byte(&data[i] ,image_buffer);
	
    }
    data[i]=0;
   // printf("%d\n",strlen(data));

  //  printf("%s\n",data);

    return e_success;
}

Status decode_lsb_to_byte(char *data, char *image_buffer)
{
    for(int i=0; i<8 ; i++)
    {
	*data = (*data | ((image_buffer[i] & 1) << ( 7 - i)));
    }
//	printf("%c",*data);
}

Status dec_secret_file_extn_size(DecodeInfo *decInfo)
{
   int size=0;

    char image_buffer[32];
    fread(image_buffer,sizeof(image_buffer),1,decInfo->fptr_stego_image);
    decode_size_lsb(&(size),image_buffer);
    decInfo->size_extn=size;
    return e_success;
   // printf("%d",decInfo->size_extn);

}
Status decode_size_lsb(int *size, char *image_buffer)
{
    for(int i=0 ; i < 32 ; i++)
    {
	*size = (*size | ((image_buffer[i] & 1) << (31-i)));
    }

    return e_success;
}
Status decode_secret_file_extn( DecodeInfo *decInfo)
{
     char ext[decInfo->size_extn]; 
    if(decode_image_to_data(ext,decInfo->size_extn,decInfo->fptr_stego_image,decInfo->fptr_secret)==e_success)
//	printf("\n%s",ext);
	return e_success;
}
Status decode_secret_file_size( DecodeInfo *decInfo)
{
    dec_secret_file_extn_size(decInfo);
    return e_success;
}
Status decode_secret_file_data(DecodeInfo *decInfo)
{
 //   printf("data size=%d\n",decInfo->size_extn);
    char str[decInfo->size_extn];
    decode_image_to_data(str,decInfo->size_extn,decInfo->fptr_stego_image,decInfo->fptr_secret);
    fwrite(str,decInfo->size_extn-1,1,decInfo->fptr_secret);
    return e_success;
}





